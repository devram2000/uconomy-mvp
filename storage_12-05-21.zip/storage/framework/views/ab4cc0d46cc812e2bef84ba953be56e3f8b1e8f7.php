<?php $__env->startPush('scripts'); ?>
    
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">

    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>



    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
  
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.9.0/fullcalendar.css" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.24.0/moment.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.9.0/fullcalendar.js"></script>
  
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css" />


<?php $__env->stopPush(); ?>
<?php if($is_admin): ?>
    <section id="upay">
        <section id="upay-buy">

            <div id="upay-title"> 
                <?php echo e(__('Admin Panel')); ?>

            </div>
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['id' => 'upay-button','type' => 'button','wire:click' => 'redirectAdmin']]); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['id' => 'upay-button','type' => 'button','wire:click' => 'redirectAdmin']); ?>
                <?php echo e(__('View Payments')); ?>

             <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        </section>
    </section>
<?php else: ?>
<section id="upay">
    <section id="upay-buy">
        
        <div id="upay-title"> 
            <?php echo e(__('UPay')); ?>

        </div>
        <?php
    /* @if(!$is_approved)
            <div class="text-center"> 
                {{ __('Thank you for signing up!') }}</br></br>
                {{ __('To make a transaction with your $250 limit, please
                    sign up for our ') }}<a href="https://www.uconomy.com">waitlist</a>{{ __('.') }}</br>
                {{ __('If you are already signed up, you can fill out sections of your profile to boost
                    your spot!') }}</br></br>

            </div>

            @component('Illuminate\View\AnonymousComponent', 'jet-button', ['view' => 'jetstream::components.button','data' => ['id' => 'upay-button','type' => 'button','wire:click' => 'redirectProfile']])
<?php $component->withAttributes(['id' => 'upay-button','type' => 'button','wire:click' => 'redirectProfile']); ?>
                {{ __('Profile') }}
             @endComponentClass
        @else */
?>
        
            <div> 
                <?php echo e(__('Your amount available to spend is $')); ?><?php echo e($spending_amount); ?>


            </div>
            <div>
                <?php if($profile_completed && $spending_amount >= 10): ?>
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['id' => 'upay-button','type' => 'button','wire:click' => 'redirectUPay']]); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['id' => 'upay-button','type' => 'button','wire:click' => 'redirectUPay']); ?>
                    <?php echo e(__('Create a Payment Plan')); ?>

                 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>  
                <?php elseif($spending_amount >= 10): ?>
                <div id="profile-button">
                    <div> <?php echo e(__(' Please complete the ')); ?> <?php echo e($profile_sections); ?> <?php echo e(__(' of your Profile before making your payment plan.')); ?> </div> </br>
                
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['id' => 'upay-button','type' => 'button','wire:click' => 'redirectProfile']]); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['id' => 'upay-button','type' => 'button','wire:click' => 'redirectProfile']); ?>
                        <?php echo e(__('Profile')); ?>

                     <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                </div>
                <?php endif; ?>
                <?php
    /*        @endif
*/
?>
        </div>
    </section>
    <?php if($remaining_balance): ?>
    <section id="upay-balance">
       
        <div id="payment-title"> 
            <?php echo e(__('Your upcoming payment dates')); ?> 
        </div> 
         <div>
            <?php echo e(__('Total Remaining Balance: $')); ?><?php echo e($remaining_balance); ?>

        </div></br>
        <div class="calendar" id="mainCalendar"> 
                                    </div>
                                    <script>
                                        $(document).ready(viewDates());

                                    
                                        
                                        function viewDates() {
                                        
                                        var SITEURL = "<?php echo e(url('/')); ?>";
                                        
                                        $.ajaxSetup({
                                            headers: {
                                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                                            }
                                        });

                                        

                                    

                                        var calendar = $('#mainCalendar').fullCalendar({
                                                            // events: SITEURL + "/transact",
                                                            events: <?php echo json_encode($events_and_fees, 15, 512) ?>,
                                                            editable: false,
                                                            eventColor: '#7cd9edff',
                                                            height: 'auto',
                                                            // eventBorderColor: 'black',

                                                            defaultView: 'month',
                                                            header: {
                                                                left:   'title',
                                                                center: '',
                                                                right:  'today prev,next month basicWeek'
                                                            },

                                                            // validRange: function(nowDate) {
                                                            //     return {
                                                            //         start: nowDate.clone().subtract(1, 'days'),
                                                            //         end: nowDate.clone().add(3, 'months')
                                                            //     };
                                                            // },
                                                    
                                                            eventRender: function (event, element, view) {
                                                                if (event.allDay === 'true') {
                                                                        event.allDay = true;
                                                                } else {
                                                                        event.allDay = false;
                                                                }
                                                            },
                                                            selectable: false,
                                        
                                                        });
                                        
                                        }
                                        
                                        
                                        
                                    </script>

    </section>

    <?php endif; ?>
    <?php if($has_transactions): ?>
    <section id="upay-transactions">
        <div id="transactions-title" class="text-center "> 
            <?php echo e(__('Your transactions')); ?>

        </div>

        <div id="transaction-list">
            <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div id="transaction-item">
                <div class="transaction-sub"><b>Start Date</b>: <?php echo e(date('m/d/Y', strtotime($item->start_date))); ?></div>
                <div class="transaction-sub"><b>Category</b>: <?php echo e($item->category); ?></div>
                <div class="transaction-sub"><b>Description</b>: <?php echo e($item->description); ?></div>
                <div class="transaction-sub"><b>Estimated Completion</b>: <?php echo e(date('m/d/Y', strtotime($item->due_date))); ?></div>
                <div class="transaction-sub"><b>Remaining Balance</b>: <?php echo e(__('$')); ?><?php echo e($item->amount); ?></div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
        

    </div>

    
    <?php endif; ?>
</div>    
<?php endif; ?>



<?php /* 
    <div class="p-6 border-t border-gray-200 md:border-l bg-gray-200 bg-opacity-25 grid grid-cols-1 md:grid-cols-2">
    <div class="flex justify-between">
        <div class="p-6">
            <div class="flex items-center">
                <svg fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewBox="0 0 24 24" class="w-8 h-8 text-gray-400"><path d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"></path></svg>
                <div class="ml-4 text-lg text-gray-600 leading-7 font-semibold">{{ __('UPay') }}</div>
            </div>
    
            <div class="ml-12">
                <div class="mt-2 text-sm text-gray-500">
                    {{ __('Start Beta Testing with UPay today!') }}
                </div>
            </div>
            
        </div>

                                        
    </div>  
    <div id="upay">
        @component('Illuminate\View\AnonymousComponent', 'jet-button', ['view' => 'jetstream::components.button','data' => ['id' => 'upay-button','type' => 'button','wire:click' => 'redirectUPay']])
<?php $component->withAttributes(['id' => 'upay-button','type' => 'button','wire:click' => 'redirectUPay']); ?>
            {{ __('Start Today') }}
         @endComponentClass  
    
    </div>    
</div>

*/ ?> 


<?php /**PATH /Volumes/Storage/Documents/Uconomy/workspace/uconomy-mvp/resources/views/livewire/start-u-pay.blade.php ENDPATH**/ ?>