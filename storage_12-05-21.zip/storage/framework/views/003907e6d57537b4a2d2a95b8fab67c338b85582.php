<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->startPush('scripts'); ?>
    <script
    src="https://code.jquery.com/jquery-3.3.1.js"
    integrity="sha256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60="
    crossorigin="anonymous"></script>


    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">

    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>



    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" />


    <?php $__env->stopPush(); ?>

     <?php $__env->slot('header', null, []); ?> 
    <div class="font-semibold text-xl text-gray-800 leading-tight">
        <?php echo e(__('Uconomy')); ?>

    </div>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg">
                
                
                <?php if(request()->get('verified') == "0"): ?>
                    <script>window.location = "/user/profile?verified=0";</script>


                <?php elseif(request()->get('verified') == "1"): ?>
                    <script>window.location = "/user/profile?verified=1";</script>
                  
                <?php elseif(request()->get('verified') == "2"): ?>
                    <script>window.location = "/user/profile?verified=2";</script>

                <?php endif; ?>
                



                  
                
                <div class="p-6 sm:px-20 bg-white border-b border-gray-200" id="dash">
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('start-u-pay')->html();
} elseif ($_instance->childHasBeenRendered('Vs87MtJ')) {
    $componentId = $_instance->getRenderedChildComponentId('Vs87MtJ');
    $componentTag = $_instance->getRenderedChildComponentTagName('Vs87MtJ');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('Vs87MtJ');
} else {
    $response = \Livewire\Livewire::mount('start-u-pay');
    $html = $response->html();
    $_instance->logRenderedChild('Vs87MtJ', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                </div>

            </div>
        </div>
    </div>
    

 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH /Users/devmac/Storage/Documents/Uconomy/workspace/uconomy-mvp/resources/views/dashboard.blade.php ENDPATH**/ ?>