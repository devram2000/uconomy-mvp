<script>
    var calendar;
    $(document).ready(function(){
        var calendarEl = document.getElementById('calendar-<?php echo e($id); ?>')
        calendar = new FullCalendar.Calendar(calendarEl,
            <?php echo $options; ?>,
        );
        calendar.render();
    });
</script>
<?php /**PATH /Volumes/Storage/Documents/Uconomy/workspace/uconomy-mvp/vendor/acaronlex/laravel-calendar/src/views//script.blade.php ENDPATH**/ ?>