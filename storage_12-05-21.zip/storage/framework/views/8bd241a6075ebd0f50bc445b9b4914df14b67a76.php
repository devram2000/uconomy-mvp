<?php $__env->startPush('scripts'); ?>

    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">

    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>



    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
  
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.9.0/fullcalendar.css" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.24.0/moment.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.9.0/fullcalendar.js"></script>
  
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css" />


<?php $__env->stopPush(); ?>

 <?php $__env->slot('header', null, []); ?> 
    <div class="font-semibold text-xl text-gray-800 leading-tight">
        <?php echo e(__('Uconomy')); ?>

    </div>
 <?php $__env->endSlot(); ?>

<div class="py-12">
    <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
        <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg">
            <div class="p-6 sm:px-20 bg-white border-b border-gray-200" id="dash">
                <section id="admin">
                        <div>
                        <h1 class ="m-0"> 
                        <?php echo e(__('All Payments')); ?>

                        </h1><?php echo e(__('(User ID: Amount)')); ?></div></br>
                        <div class="calendar" id="total"> 
                                    </div></br></br>
                                    <script>
                                        $(document).ready(viewDates());

                                    
                                        
                                        function viewDates() {
                                        
                                        var SITEURL = "<?php echo e(url('/')); ?>";
                                        
                                        $.ajaxSetup({
                                            headers: {
                                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                                            }
                                        });

                                        

                                    

                                        var calendar = $('#total').fullCalendar({
                                                            events: <?php echo json_encode($this->combined_events, 15, 512) ?>,
                                                            editable: false,
                                                            eventColor: '#7cd9edff',
                                                            height: 'auto',

                                                            defaultView: 'basicWeek',
                                                            header: {
                                                                left:   'title',
                                                                center: '',
                                                                right:  'today prev,next month basicWeek'
                                                            },

                                                            // validRange: function(nowDate) {
                                                            //     return {
                                                            //         start: nowDate.clone().subtract(1, 'days'),
                                                            //         end: nowDate.clone().add(3, 'months')
                                                            //     };
                                                            // },
                                                    
                                                            eventRender: function (event, element, view) {
                                                                if (event.allDay === 'true') {
                                                                        event.allDay = true;
                                                                } else {
                                                                        event.allDay = false;
                                                                }
                                                            },
                                                            selectable: false,
                                        
                                                        });
                                        
                                        }
                                        
                                        
                                        
                                    </script>
                    <h1><?php echo e(__('Users')); ?></h1>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <h4> 
                        <?php echo e($u->id); ?><?php echo e(__(': ')); ?><?php echo e($u->name); ?>

                        </h4></br>
                        <div class="calendar" id="<?php echo e($u->id); ?>"> </div>

                        <?php if($ids[$u->id] != NULL): ?>  
                         
                            <div class="mt-2" id = "license-images">
                                <img src="/storage/ids/<?php echo e($ids[$u->id]['photo1']); ?>" id="license-image" />
                                <?php if($ids[$u->id]['photo2'] != NULL): ?>  
                                <img src="/storage/ids/<?php echo e($ids[$u->id]['photo2']); ?>" id="license-image" />
                                <?php endif; ?>
                                    
                            </div>

                           

                        <?php endif; ?>
                                
                                </br></br>
                                    <script>
                                        $(document).ready(viewDates());

                                    
                                        
                                        function viewDates() {
                                        
                                        var SITEURL = "<?php echo e(url('/')); ?>";
                                        
                                        $.ajaxSetup({
                                            headers: {
                                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                                            }
                                        });

                                        

                                    

                                        var calendar = $('#<?php echo e($u->id); ?>').fullCalendar({
                                                            events: <?php echo json_encode($this->events[$u->id], 15, 512) ?>,
                                                            editable: false,
                                                            eventColor: '#7cd9edff',
                                                            height: 'auto',

                                                            defaultView: 'basicWeek',
                                                            header: {
                                                                left:   'title',
                                                                center: '',
                                                                right:  'today prev,next month basicWeek'
                                                            },

                                                            // validRange: function(nowDate) {
                                                            //     return {
                                                            //         start: nowDate.clone().subtract(1, 'days'),
                                                            //         end: nowDate.clone().add(3, 'months')
                                                            //     };
                                                            // },
                                                    
                                                            eventRender: function (event, element, view) {
                                                                if (event.allDay === 'true') {
                                                                        event.allDay = true;
                                                                } else {
                                                                        event.allDay = false;
                                                                }
                                                            },
                                                            selectable: false,
                                        
                                                        });
                                        
                                        }
                                        
                                        
                                        
                                    </script>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </section>
            </div>
        </div>
    </div>
</div><?php /**PATH /Users/devmac/Storage/Documents/Uconomy/workspace/uconomy-mvp/resources/views/livewire/admin.blade.php ENDPATH**/ ?>