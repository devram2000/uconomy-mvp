<?php echo e($slot); ?>

<?php /**PATH /home/uconomyc/transact.uconomy.com/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>