<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /Users/devmac/Storage/Documents/Uconomy/workspace/uconomy-mvp/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/button.blade.php ENDPATH**/ ?>